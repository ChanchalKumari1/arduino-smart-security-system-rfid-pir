/*
 * ============================================================
 *   RFID Card Enrollment Tool
 *   Arduino Smart Security System — DigitalMonk
 *
 *   Use this sketch to:
 *   - Enroll new RFID cards (saves to EEPROM)
 *   - Read & display card UIDs
 *   - List all enrolled cards
 *   - Remove specific cards
 *   - Factory reset (clear all cards)
 *
 *   Upload to Arduino ONLY for card management.
 *   Switch back to Smart_Security_Main.ino for normal operation.
 *   EEPROM data is shared between both sketches.
 *
 *   Wiring (same as main sketch):
 *   RFID SS  → Pin 53
 *   RFID RST → Pin 49
 *   SPI pins → 50, 51, 52
 * ============================================================
 */

#include <SPI.h>
#include <MFRC522.h>
#include <EEPROM.h>

#define RFID_SS_PIN   53
#define RFID_RST_PIN  49
#define MAX_CARDS     20
#define UID_SIZE      4
#define EEPROM_CARD_CNT  0
#define EEPROM_UID_START 10

MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);

int cardCount = 0;

// ─── EEPROM Helpers ────────────────────────────────────────
void saveCount(int c) { EEPROM.write(EEPROM_CARD_CNT, c); }
int  loadCount()      {
  int c = EEPROM.read(EEPROM_CARD_CNT);
  return (c > MAX_CARDS || c < 0) ? 0 : c;
}

void saveUID(int idx, byte uid[]) {
  int addr = EEPROM_UID_START + idx * UID_SIZE;
  for (int i = 0; i < UID_SIZE; i++) EEPROM.write(addr + i, uid[i]);
}

void loadUID(int idx, byte out[]) {
  int addr = EEPROM_UID_START + idx * UID_SIZE;
  for (int i = 0; i < UID_SIZE; i++) out[i] = EEPROM.read(addr + i);
}

String uidStr(byte uid[]) {
  String s = "";
  for (int i = 0; i < UID_SIZE; i++) {
    if (uid[i] < 0x10) s += "0";
    s += String(uid[i], HEX);
    if (i < UID_SIZE-1) s += ":";
  }
  s.toUpperCase();
  return s;
}

bool isEnrolled(byte uid[]) {
  byte stored[UID_SIZE];
  for (int i = 0; i < cardCount; i++) {
    loadUID(i, stored);
    bool m = true;
    for (int j = 0; j < UID_SIZE; j++) if (stored[j] != uid[j]) { m=false; break; }
    if (m) return true;
  }
  return false;
}

// ─── List All Cards ────────────────────────────────────────
void listCards() {
  Serial.print(F("\n=== Enrolled Cards ("));
  Serial.print(cardCount);
  Serial.println(F(") ==="));
  byte uid[UID_SIZE];
  for (int i = 0; i < cardCount; i++) {
    loadUID(i, uid);
    Serial.print(i + 1); Serial.print(F(". "));
    Serial.println(uidStr(uid));
  }
  Serial.println(F("==================="));
}

// ─── Enroll a Card ─────────────────────────────────────────
void enrollMode() {
  if (cardCount >= MAX_CARDS) {
    Serial.println(F("Storage full! Remove a card first."));
    return;
  }
  Serial.println(F("\n[ENROLL] Tap card to enroll (15s timeout)..."));
  unsigned long t = millis();
  while (millis() - t < 15000) {
    if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) { delay(100); continue; }
    byte uid[UID_SIZE];
    for (int i = 0; i < UID_SIZE; i++) uid[i] = rfid.uid.uidByte[i];
    String us = uidStr(uid);
    if (isEnrolled(uid)) {
      Serial.print(F("Already enrolled: ")); Serial.println(us);
    } else {
      saveUID(cardCount, uid);
      cardCount++;
      saveCount(cardCount);
      Serial.print(F("✅ Enrolled: ")); Serial.println(us);
      Serial.print(F("Total cards: ")); Serial.println(cardCount);
    }
    rfid.PICC_HaltA(); rfid.PCD_StopCrypto1();
    return;
  }
  Serial.println(F("Timeout — no card detected."));
}

// ─── Read Card UID ─────────────────────────────────────────
void readMode() {
  Serial.println(F("\n[READ] Tap any card to read UID (10s)..."));
  unsigned long t = millis();
  while (millis() - t < 10000) {
    if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) { delay(100); continue; }
    byte uid[UID_SIZE];
    for (int i = 0; i < UID_SIZE; i++) uid[i] = rfid.uid.uidByte[i];
    Serial.print(F("UID: ")); Serial.println(uidStr(uid));
    Serial.print(F("Status: ")); Serial.println(isEnrolled(uid) ? "ENROLLED" : "NOT enrolled");
    rfid.PICC_HaltA(); rfid.PCD_StopCrypto1();
    return;
  }
  Serial.println(F("Timeout."));
}

// ─── Remove Card ───────────────────────────────────────────
void removeMode() {
  Serial.println(F("\n[REMOVE] Tap card to remove (10s)..."));
  unsigned long t = millis();
  while (millis() - t < 10000) {
    if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) { delay(100); continue; }
    byte uid[UID_SIZE];
    for (int i = 0; i < UID_SIZE; i++) uid[i] = rfid.uid.uidByte[i];
    String us = uidStr(uid);
    byte stored[UID_SIZE];
    bool found = false;
    for (int i = 0; i < cardCount; i++) {
      loadUID(i, stored);
      bool m = true;
      for (int j = 0; j < UID_SIZE; j++) if (stored[j] != uid[j]) { m=false; break; }
      if (m) {
        // Shift remaining cards down
        for (int k = i; k < cardCount - 1; k++) {
          byte next[UID_SIZE]; loadUID(k+1, next); saveUID(k, next);
        }
        cardCount--; saveCount(cardCount);
        Serial.print(F("✅ Removed: ")); Serial.println(us);
        found = true; break;
      }
    }
    if (!found) { Serial.print(F("Not found: ")); Serial.println(us); }
    rfid.PICC_HaltA(); rfid.PCD_StopCrypto1();
    return;
  }
  Serial.println(F("Timeout."));
}

// ─── Factory Reset ─────────────────────────────────────────
void factoryReset() {
  Serial.println(F("\n[RESET] Type 'CONFIRM' to erase all cards:"));
  unsigned long t = millis();
  while (millis() - t < 10000) {
    if (Serial.available()) {
      String s = Serial.readStringUntil('\n'); s.trim();
      if (s == "CONFIRM") {
        for (int i = 0; i < EEPROM_UID_START + MAX_CARDS * UID_SIZE; i++)
          EEPROM.write(i, 0xFF);
        cardCount = 0; saveCount(0);
        Serial.println(F("✅ All cards erased!"));
        return;
      } else {
        Serial.println(F("Reset cancelled."));
        return;
      }
    }
    delay(100);
  }
  Serial.println(F("Timeout — reset cancelled."));
}

// ─── SETUP ─────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  SPI.begin();
  rfid.PCD_Init();
  cardCount = loadCount();

  Serial.println(F("\n================================"));
  Serial.println(F("  RFID Card Enrollment Tool"));
  Serial.println(F("  Arduino Smart Security System"));
  Serial.println(F("  DigitalMonk"));
  Serial.println(F("================================"));
  Serial.print(F("Cards in EEPROM: ")); Serial.println(cardCount);
  Serial.println(F("\nCommands: enroll | read | remove | list | reset | help"));
}

// ─── LOOP ──────────────────────────────────────────────────
void loop() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n'); cmd.trim();

  if      (cmd == "enroll") enrollMode();
  else if (cmd == "read")   readMode();
  else if (cmd == "remove") removeMode();
  else if (cmd == "list")   listCards();
  else if (cmd == "reset")  factoryReset();
  else if (cmd == "help") {
    Serial.println(F("enroll  - Add new RFID card to system"));
    Serial.println(F("read    - Read UID of any card"));
    Serial.println(F("remove  - Remove a card from system"));
    Serial.println(F("list    - List all enrolled cards"));
    Serial.println(F("reset   - Factory reset (erase all cards)"));
  }
}
