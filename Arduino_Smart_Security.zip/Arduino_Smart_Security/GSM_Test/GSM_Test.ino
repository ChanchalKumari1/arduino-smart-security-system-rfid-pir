/*
 * ============================================================
 *   GSM SIM800L Test Tool
 *   Arduino Smart Security System — DigitalMonk
 *
 *   Test GSM module:
 *   - Send test SMS to a number
 *   - Check signal strength
 *   - Make a test call
 *   - Verify SIM card status
 *
 *   Wiring:
 *   SIM800L TX → Arduino Pin 10 (SoftwareSerial RX)
 *   SIM800L RX → Arduino Pin 11 (SoftwareSerial TX)
 *   SIM800L VCC → 4.2V (LiPo recommended, NOT 5V!)
 *   SIM800L GND → GND
 *
 *   ⚠️ SIM800L needs 2A peak current — use dedicated power supply!
 * ============================================================
 */

#include <SoftwareSerial.h>

SoftwareSerial gsm(10, 11); // RX, TX

#define TEST_NUMBER "+91XXXXXXXXXX"  // Change to your number

String gsmResponse = "";

void sendAT(const char* cmd, int waitMs = 1000) {
  Serial.print(F(">>> "));
  Serial.println(cmd);
  gsm.println(cmd);
  unsigned long t = millis();
  while (millis() - t < waitMs) {
    while (gsm.available()) {
      char c = gsm.read();
      Serial.write(c);
      gsmResponse += c;
    }
  }
  Serial.println();
}

void sendSMS(const char* number, const char* msg) {
  Serial.println(F("\n--- Sending SMS ---"));
  sendAT("AT+CMGF=1", 500);
  String cmd = "AT+CMGS=\"";
  cmd += number;
  cmd += "\"";
  sendAT(cmd.c_str(), 1000);
  gsm.print(msg);
  gsm.write(26); // Ctrl+Z
  delay(5000);
  while (gsm.available()) Serial.write(gsm.read());
  Serial.println(F("\n--- SMS Done ---"));
}

void setup() {
  Serial.begin(115200);
  gsm.begin(9600);
  delay(3000); // SIM800L boot time

  Serial.println(F("=== GSM SIM800L Test ==="));
  Serial.println(F("Commands: at | status | signal | sms | help\n"));

  // Basic init
  sendAT("AT");
  sendAT("AT+CMGF=1");  // Text mode
  sendAT("AT+CREG?");   // Network registration
}

void loop() {
  // Forward GSM → Serial
  while (gsm.available()) Serial.write(gsm.read());

  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n'); cmd.trim();

  if (cmd == "at") {
    sendAT("AT");

  } else if (cmd == "status") {
    sendAT("AT+CREG?");   // Registration status
    sendAT("AT+COPS?");   // Operator
    sendAT("AT+CIMI");    // IMSI
    sendAT("AT+CNUM");    // SIM number

  } else if (cmd == "signal") {
    sendAT("AT+CSQ");     // Signal quality 0-31 (higher=better)

  } else if (cmd == "sms") {
    sendSMS(TEST_NUMBER, "TEST: Arduino Smart Security System is online!");

  } else if (cmd == "call") {
    Serial.println(F("Making test call (hangs up after 5s)..."));
    String c = "ATD"; c += TEST_NUMBER; c += ";";
    sendAT(c.c_str(), 5000);
    sendAT("ATH", 500); // Hang up

  } else if (cmd == "help") {
    Serial.println(F("at     - Send AT command"));
    Serial.println(F("status - SIM & network status"));
    Serial.println(F("signal - Signal strength (0-31)"));
    Serial.println(F("sms    - Send test SMS"));
    Serial.println(F("call   - Make test call"));

  } else if (cmd.startsWith("raw:")) {
    sendAT(cmd.substring(4).c_str());
  }
}
