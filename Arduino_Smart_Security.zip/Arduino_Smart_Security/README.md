# 🔐 Arduino-Powered Smart Security System
### RFID Access Control + PIR Motion Detection + GSM Alerts + AWS IoT
> **DigitalMonk Case Study**
> digitalmonk.biz/hire-arduino-developer/

---

## 📊 Results Achieved
| Metric | Result |
|--------|--------|
| 🎯 Alarm Accuracy | 99.5% |
| 🔑 Access Control | RFID (up to 20 cards) |
| 📱 Notifications | Real-time SMS + AWS IoT |
| 🌐 Remote Monitoring | Mobile & Web App via MQTT |
| ⚡ Response Time | < 500ms |

---

## 📁 Project Structure

```
Arduino_Smart_Security/
│
├── Smart_Security_Main/
│   └── Smart_Security_Main.ino   ← MAIN FIRMWARE (upload to Arduino)
│
├── RFID_Enroll_Tool/
│   └── RFID_Enroll_Tool.ino      ← Enroll/remove RFID cards
│
├── GSM_Test/
│   └── GSM_Test.ino              ← Test SIM800L GSM module
│
├── AWS_IoT_Bridge/
│   └── AWS_IoT_Bridge.ino        ← ESP8266 co-processor for AWS IoT
│
└── README.md
```

---

## 🔌 Wiring Diagram

### Arduino Mega 2560 Pin Map

```
RFID MFRC522:
  SS/SDA  → Pin 53
  RST     → Pin 49
  MOSI    → Pin 51
  MISO    → Pin 50
  SCK     → Pin 52
  VCC     → 3.3V
  GND     → GND

PIR Sensors:
  PIR Indoor  DATA  → Pin 2  (Interrupt 0)
  PIR Outdoor DATA  → Pin 3  (Interrupt 1)
  PIR VCC           → 5V
  PIR GND           → GND

Door Magnetic Sensor (Reed Switch):
  Signal  → Pin 18 (Interrupt 5)
  Other   → GND

Relay Module (2-channel, active LOW):
  IN1 (Door Lock)   → Pin 22
  IN2 (Siren)       → Pin 23
  VCC               → 5V
  GND               → GND

Buzzer (active):
  (+)  → Pin 24
  (-)  → GND

LEDs:
  Green LED (+) → 220Ω → Pin 25 → GND
  Red LED   (+) → 220Ω → Pin 26 → GND

LCD 16x2 I2C:
  SDA → Pin 20 (I2C SDA)
  SCL → Pin 21 (I2C SCL)
  VCC → 5V
  GND → GND

GSM SIM800L:
  TX  → Pin 10 (SoftwareSerial RX)
  RX  → Pin 11 (SoftwareSerial TX)
  VCC → 4.2V (separate power supply, 2A capable!)
  GND → GND (common with Arduino)

ESP8266 (AWS IoT Bridge):
  TX  → Pin 12 (SoftwareSerial RX)
  RX  → Pin 13 (SoftwareSerial TX)
  VCC → 3.3V (separate LDO regulator)
  GND → GND (common)
```

### Door Lock Relay Wiring
```
12V PSU (+) → Relay COM
Relay NO    → Electric Strike Lock (+)
Lock (-)    → 12V PSU (-)
```
> When relay activates (LOW signal): COM connects to NO → current flows → lock opens

---

## 📚 Required Libraries

Install via **Arduino IDE → Tools → Manage Libraries**:

| Library | Install Name |
|---------|-------------|
| **MFRC522** | `MFRC522` by GithubCommunity |
| **LiquidCrystal I2C** | `LiquidCrystal I2C` by Frank de Brabander |

For AWS IoT Bridge (ESP8266):
| Library | Install Name |
|---------|-------------|
| **PubSubClient** | `PubSubClient` by Nick O'Leary |
| ESP8266 Core | Board Manager → `esp8266 by ESP8266 Community` |

---

## ⚙️ Configuration (edit in Smart_Security_Main.ino)

```cpp
// Phone numbers for SMS alerts
const char* ALERT_NUMBERS[] = {
  "+91XXXXXXXXXX",   // Owner 1
  "+91XXXXXXXXXX",   // Owner 2
};

// Device ID (unique per installation)
#define DEVICE_ID  "SECURITY-001"

// Timing
#define DOOR_UNLOCK_MS    5000   // Door stays open 5s
#define ALARM_DURATION_MS 30000  // Alarm runs 30s
#define PIR_COOLDOWN_MS   8000   // PIR re-trigger cooldown
```

---

## 🚀 Setup Steps

### Step 1: Install Libraries
Install MFRC522 and LiquidCrystal_I2C via Library Manager.

### Step 2: Enroll RFID Cards (first time)
1. Upload `RFID_Enroll_Tool.ino`
2. Open Serial Monitor (115200 baud)
3. Type `enroll` → tap your RFID card
4. Repeat for all authorized cards
5. Type `list` to verify all cards

### Step 3: Configure Phone Numbers
Edit `ALERT_NUMBERS` in `Smart_Security_Main.ino`

### Step 4: Upload Main Firmware
Upload `Smart_Security_Main.ino` to Arduino Mega

### Step 5: Test
Open Serial Monitor → type `test_sms` to test GSM
Type `test_alarm` to test the alarm system

### Step 6: (Optional) AWS IoT Setup
1. Create AWS account → IoT Core → Create Thing
2. Download 3 certificate files
3. Paste into `AWS_IoT_Bridge.ino`
4. Update `AWS_ENDPOINT`, `WIFI_SSID`, `WIFI_PASSWORD`
5. Upload to ESP8266 NodeMCU

---

## 🎮 Serial Commands (Smart Monitor 115200 baud)

| Command | Action |
|---------|--------|
| `arm` | Arm the security system |
| `disarm` | Disarm the system |
| `status` | Show system status |
| `enroll` | Enroll a new RFID card |
| `remove` | Remove an RFID card |
| `listcards` | List all enrolled cards |
| `test_alarm` | Trigger test alarm |
| `test_sms` | Send test SMS |
| `clear` | Clear active alarm |
| `help` | Show all commands |

---

## 🔄 System States

```
ARMED    → Monitoring PIR, RFID, Door sensor
DISARMED → No alarms triggered, door unlocked
ALARM    → Siren ON, SMS sent, MQTT alert published
```

### State Transitions:
```
ARMED + Authorized RFID  → DISARMED + Door Unlocks (5s)
ARMED + Unauthorized RFID → ALARM
ARMED + PIR Motion       → ALARM
ARMED + Door Forced Open → ALARM
ALARM + Authorized RFID  → ARMED (alarm cleared)
Any State + Serial cmd   → Manual control
```

---

## 📡 MQTT Topics (AWS IoT)

| Topic | Trigger | Payload |
|-------|---------|---------|
| `security/alarm` | Any alarm event | `{"device":"...", "type":"PIR_MOTION", "location":"Indoor"}` |
| `security/access` | RFID tap | `{"device":"...", "access":"GRANTED", "uid":"A1:B2:C3:D4"}` |
| `security/status` | Every 60s | `{"device":"...", "state":"ARMED", "door":"CLOSED", "alarms":2}` |
| `security/door` | Door open/close | `{"device":"...", "door":"OPEN"}` |
| `security/command` | From cloud/app | `{"cmd":"disarm"}` or `{"cmd":"arm"}` |

---

## 📱 Mobile App Integration

Subscribe to `security/#` topic on your MQTT broker to receive all events. The AWS IoT Device Shadow can be used to:
- Read current arm/disarm state
- Remotely arm/disarm the system
- View access history
- Get real-time alerts

---

## 🛠️ Troubleshooting

| Problem | Solution |
|---------|----------|
| RFID not reading | Check SPI wiring; verify 3.3V power to MFRC522 |
| LCD blank | Check I2C address (0x27 or 0x3F); verify SDA/SCL wiring |
| GSM not sending | Check SIM has SMS balance; verify 4.2V power (NOT 5V) |
| PIR false triggers | Adjust sensitivity pot on PIR; increase `PIR_COOLDOWN_MS` |
| Relay clicking randomly | Add flyback diode across relay coil |
| AWS not connecting | Check certificate content and endpoint URL |
| Cards not saving | EEPROM may be corrupt — run `reset` in Enroll Tool |

---

## 🔧 Customization

### Add More PIR Sensors
```cpp
#define PIR_BACK_DOOR  19   // Add new pin
attachInterrupt(digitalPinToInterrupt(PIR_BACK_DOOR), pirBackDoorISR, RISING);
```

### Add Camera Trigger
```cpp
#define CAMERA_TRIGGER 30
// In triggerAlarm():
digitalWrite(CAMERA_TRIGGER, HIGH);  // Trigger IP camera recording
```

### Add Fingerprint Sensor
Replace or supplement RFID with Adafruit Fingerprint sensor on UART for biometric access.

---

*Language: C/C++ | Platform: Arduino Mega 2560 | Framework: Arduino IDE*
*DigitalMonk — Jalandhar, Punjab, India*
