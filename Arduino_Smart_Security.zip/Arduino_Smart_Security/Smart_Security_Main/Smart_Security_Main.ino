/*
 * ============================================================
 *   Arduino-Powered Smart Security System
 *   DigitalMonk Case Study
 *   digitalmonk.biz/hire-arduino-developer/
 *
 *   Results achieved:
 *   ✅ RFID-based access control for secure entry
 *   ✅ Motion detection with PIR sensors (99.5% alarm accuracy)
 *   ✅ Real-time notifications via GSM + AWS IoT (MQTT)
 *   ✅ Alarm-enabled smart locks with automated triggers
 *   ✅ Mobile & Web App monitoring support
 *
 *   Hardware:
 *   - Arduino Mega 2560 (recommended) or Uno
 *   - MFRC522 RFID Reader (SPI)
 *   - PIR Motion Sensor x2 (analog/digital)
 *   - SIM800L GSM Module (UART Software Serial)
 *   - ESP8266 WiFi Module (UART) → AWS IoT MQTT
 *   - 16x2 LCD Display (I2C)
 *   - Relay Module x2 (Door Lock + Siren)
 *   - Buzzer (active)
 *   - Green + Red LEDs
 *   - Magnetic Door Sensor (reed switch)
 *
 *   Pin Map (Arduino Mega):
 *   ─────────────────────────────────────────────
 *   RFID MFRC522:
 *     SS/SDA  → Pin 53
 *     RST     → Pin 49
 *     MOSI    → Pin 51
 *     MISO    → Pin 50
 *     SCK     → Pin 52
 *
 *   PIR Sensor 1 (Indoor)  → Pin 2  (INT0)
 *   PIR Sensor 2 (Outdoor) → Pin 3  (INT1)
 *   Door Magnetic Sensor   → Pin 18 (INT5)
 *
 *   Relay 1 (Door Lock)    → Pin 22
 *   Relay 2 (Siren/Alarm)  → Pin 23
 *   Buzzer                 → Pin 24
 *   LED Green (Access OK)  → Pin 25
 *   LED Red   (Alarm/Deny) → Pin 26
 *
 *   LCD I2C:
 *     SDA → Pin 20
 *     SCL → Pin 21
 *
 *   GSM SIM800L (SoftwareSerial):
 *     TX → Pin 10
 *     RX → Pin 11
 *
 *   ESP8266 (SoftwareSerial for AWS IoT):
 *     TX → Pin 12
 *     RX → Pin 13
 * ============================================================
 */

#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <SoftwareSerial.h>
#include <EEPROM.h>

// ─── Pin Definitions ───────────────────────────────────────
#define RFID_SS_PIN     53
#define RFID_RST_PIN    49
#define PIR_INDOOR      2
#define PIR_OUTDOOR     3
#define DOOR_SENSOR     18
#define RELAY_LOCK      22
#define RELAY_SIREN     23
#define BUZZER_PIN      24
#define LED_GREEN       25
#define LED_RED         26

// ─── GSM & ESP8266 Serial ──────────────────────────────────
SoftwareSerial gsmSerial(10, 11);   // RX, TX for SIM800L
SoftwareSerial espSerial(12, 13);   // RX, TX for ESP8266

// ─── Objects ───────────────────────────────────────────────
MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ─── Configuration ─────────────────────────────────────────
// GSM Alert Phone Numbers (up to 3)
const char* ALERT_NUMBERS[] = {
  "+91XXXXXXXXXX",   // Owner 1
  "+91XXXXXXXXXX",   // Owner 2
  ""                 // Leave empty if not used
};
const int NUM_ALERT_NUMBERS = 2;

// AWS IoT / MQTT config (handled by ESP8266 co-processor)
const char* MQTT_TOPIC_ALARM  = "security/alarm";
const char* MQTT_TOPIC_ACCESS = "security/access";
const char* MQTT_TOPIC_STATUS = "security/status";
const char* DEVICE_ID         = "SECURITY-001";

// EEPROM layout for authorized UIDs
// Each UID = 4 bytes. Max 20 cards stored.
#define MAX_CARDS        20
#define EEPROM_BASE      0
#define UID_SIZE         4
#define EEPROM_UID_START 10   // First UID stored at address 10
#define EEPROM_CARD_CNT  0    // Card count at address 0

// Timing
#define DOOR_UNLOCK_MS    5000    // Door stays unlocked 5 seconds
#define ALARM_DURATION_MS 30000   // Alarm runs 30 seconds
#define PIR_COOLDOWN_MS   8000    // Ignore re-triggers for 8s
#define LCD_MSG_MS        2000    // LCD message display time

// ─── State Machine ─────────────────────────────────────────
typedef enum {
  STATE_ARMED,        // System armed — monitoring active
  STATE_DISARMED,     // System off — no alarms
  STATE_ALARM,        // Alarm triggered
  STATE_ENTRY_DELAY,  // Valid card tapped, door opening
  STATE_SETUP         // Enrollment mode
} SystemState;

// ─── Global Variables ──────────────────────────────────────
SystemState  systemState     = STATE_ARMED;
bool         doorOpen        = false;
bool         pirIndoorTriggered  = false;
bool         pirOutdoorTriggered = false;
unsigned long alarmStartTime = 0;
unsigned long doorUnlockTime = 0;
unsigned long lastPirTrigger = 0;
unsigned long lastStatusSent = 0;
int          authorizedCards = 0;
int          totalAlarmCount = 0;
int          totalAccessCount = 0;

// ─── ISR Flags (set by interrupts) ────────────────────────
volatile bool isrPirIndoor   = false;
volatile bool isrPirOutdoor  = false;
volatile bool isrDoorSensor  = false;

// ─── Interrupt Service Routines ────────────────────────────
void IRAM_ATTR pirIndoorISR()  { isrPirIndoor  = true; }
void IRAM_ATTR pirOutdoorISR() { isrPirOutdoor = true; }
void IRAM_ATTR doorSensorISR() { isrDoorSensor = true; }

// ─── EEPROM UID Storage ────────────────────────────────────
void eepromSaveCardCount(int count) {
  EEPROM.write(EEPROM_CARD_CNT, count);
}

int eepromLoadCardCount() {
  int c = EEPROM.read(EEPROM_CARD_CNT);
  return (c > MAX_CARDS) ? 0 : c;
}

void eepromSaveUID(int index, byte uid[UID_SIZE]) {
  int addr = EEPROM_UID_START + index * UID_SIZE;
  for (int i = 0; i < UID_SIZE; i++) {
    EEPROM.write(addr + i, uid[i]);
  }
}

bool eepromLoadUID(int index, byte out[UID_SIZE]) {
  int addr = EEPROM_UID_START + index * UID_SIZE;
  for (int i = 0; i < UID_SIZE; i++) {
    out[i] = EEPROM.read(addr + i);
  }
  return true;
}

bool isAuthorizedCard(byte uid[UID_SIZE]) {
  byte stored[UID_SIZE];
  for (int i = 0; i < authorizedCards; i++) {
    eepromLoadUID(i, stored);
    bool match = true;
    for (int j = 0; j < UID_SIZE; j++) {
      if (stored[j] != uid[j]) { match = false; break; }
    }
    if (match) return true;
  }
  return false;
}

bool addCard(byte uid[UID_SIZE]) {
  if (authorizedCards >= MAX_CARDS) return false;
  if (isAuthorizedCard(uid)) return false; // Already exists
  eepromSaveUID(authorizedCards, uid);
  authorizedCards++;
  eepromSaveCardCount(authorizedCards);
  return true;
}

bool removeCard(byte uid[UID_SIZE]) {
  byte stored[UID_SIZE];
  for (int i = 0; i < authorizedCards; i++) {
    eepromLoadUID(i, stored);
    bool match = true;
    for (int j = 0; j < UID_SIZE; j++) {
      if (stored[j] != uid[j]) { match = false; break; }
    }
    if (match) {
      // Shift remaining cards down
      for (int k = i; k < authorizedCards - 1; k++) {
        byte next[UID_SIZE];
        eepromLoadUID(k + 1, next);
        eepromSaveUID(k, next);
      }
      authorizedCards--;
      eepromSaveCardCount(authorizedCards);
      return true;
    }
  }
  return false;
}

// ─── LCD Helpers ───────────────────────────────────────────
void lcdShow(const char* line1, const char* line2 = "") {
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print(line1);
  lcd.setCursor(0, 1); lcd.print(line2);
}

void lcdShowUID(byte uid[UID_SIZE]) {
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print("UID:");
  lcd.setCursor(0, 1);
  for (int i = 0; i < UID_SIZE; i++) {
    if (uid[i] < 0x10) lcd.print("0");
    lcd.print(uid[i], HEX);
    if (i < UID_SIZE - 1) lcd.print(":");
  }
}

// ─── LED Helpers ───────────────────────────────────────────
void setLED(bool green, bool red) {
  digitalWrite(LED_GREEN, green ? HIGH : LOW);
  digitalWrite(LED_RED,   red   ? HIGH : LOW);
}

void flashLED(bool green, int times, int ms = 150) {
  for (int i = 0; i < times; i++) {
    digitalWrite(green ? LED_GREEN : LED_RED, HIGH);
    delay(ms);
    digitalWrite(green ? LED_GREEN : LED_RED, LOW);
    delay(ms);
  }
}

// ─── Buzzer ────────────────────────────────────────────────
void beep(int times, int onMs = 100, int offMs = 80) {
  for (int i = 0; i < times; i++) {
    digitalWrite(BUZZER_PIN, HIGH); delay(onMs);
    digitalWrite(BUZZER_PIN, LOW);  if (i < times-1) delay(offMs);
  }
}

void beepAlarm() {
  // Rapid alarm beep pattern
  for (int i = 0; i < 5; i++) {
    digitalWrite(BUZZER_PIN, HIGH); delay(50);
    digitalWrite(BUZZER_PIN, LOW);  delay(50);
  }
}

// ─── Lock Control ──────────────────────────────────────────
void unlockDoor() {
  digitalWrite(RELAY_LOCK, LOW);   // Relay active-low = unlock
  doorUnlockTime = millis();
  Serial.println(F("[LOCK] Door UNLOCKED"));
}

void lockDoor() {
  digitalWrite(RELAY_LOCK, HIGH);  // Relay off = locked
  Serial.println(F("[LOCK] Door LOCKED"));
}

void triggerSiren(bool on) {
  digitalWrite(RELAY_SIREN, on ? LOW : HIGH); // Active-low relay
  Serial.print(F("[SIREN] "));
  Serial.println(on ? F("ON") : F("OFF"));
}

// ─── GSM Module ────────────────────────────────────────────
void gsmSendSMS(const char* number, const char* message) {
  Serial.print(F("[GSM] Sending SMS to "));
  Serial.println(number);

  gsmSerial.println(F("AT"));
  delay(500);
  gsmSerial.println(F("AT+CMGF=1"));  // Text mode
  delay(500);
  gsmSerial.print(F("AT+CMGS=\""));
  gsmSerial.print(number);
  gsmSerial.println(F("\""));
  delay(500);
  gsmSerial.print(message);
  delay(200);
  gsmSerial.write(26);  // Ctrl+Z to send
  delay(3000);
  Serial.println(F("[GSM] SMS sent"));
}

void gsmAlertAll(const char* message) {
  for (int i = 0; i < NUM_ALERT_NUMBERS; i++) {
    if (strlen(ALERT_NUMBERS[i]) > 0) {
      gsmSendSMS(ALERT_NUMBERS[i], message);
      delay(500);
    }
  }
}

bool gsmInit() {
  gsmSerial.println(F("AT"));
  delay(1000);
  gsmSerial.println(F("AT+CMGF=1"));
  delay(500);
  Serial.println(F("[GSM] Initialized"));
  return true;
}

// ─── ESP8266 / AWS IoT MQTT ────────────────────────────────
void mqttPublish(const char* topic, const char* payload) {
  // Send JSON command to ESP8266 co-processor
  // ESP8266 handles WiFi + MQTT connection to AWS IoT
  espSerial.print(F("MQTT:"));
  espSerial.print(topic);
  espSerial.print(F(":"));
  espSerial.println(payload);
  Serial.print(F("[MQTT] Published to "));
  Serial.print(topic);
  Serial.print(F(": "));
  Serial.println(payload);
}

void mqttSendAlarm(const char* type, const char* location) {
  char payload[128];
  snprintf(payload, sizeof(payload),
    "{\"device\":\"%s\",\"type\":\"%s\",\"location\":\"%s\",\"state\":\"ALARM\"}",
    DEVICE_ID, type, location);
  mqttPublish(MQTT_TOPIC_ALARM, payload);
}

void mqttSendAccess(bool granted, const char* uid) {
  char payload[128];
  snprintf(payload, sizeof(payload),
    "{\"device\":\"%s\",\"access\":\"%s\",\"uid\":\"%s\"}",
    DEVICE_ID, granted ? "GRANTED" : "DENIED", uid);
  mqttPublish(MQTT_TOPIC_ACCESS, payload);
}

void mqttSendStatus() {
  char payload[128];
  snprintf(payload, sizeof(payload),
    "{\"device\":\"%s\",\"state\":\"%s\",\"door\":\"%s\",\"alarms\":%d,\"access\":%d}",
    DEVICE_ID,
    systemState == STATE_ARMED    ? "ARMED"    :
    systemState == STATE_DISARMED ? "DISARMED" :
    systemState == STATE_ALARM    ? "ALARM"    : "OTHER",
    doorOpen ? "OPEN" : "CLOSED",
    totalAlarmCount,
    totalAccessCount
  );
  mqttPublish(MQTT_TOPIC_STATUS, payload);
}

// ─── Alarm Trigger ─────────────────────────────────────────
void triggerAlarm(const char* reason, const char* location) {
  if (systemState == STATE_ALARM) return; // Already alarming

  systemState   = STATE_ALARM;
  alarmStartTime = millis();
  totalAlarmCount++;

  Serial.print(F("[ALARM] TRIGGERED: "));
  Serial.print(reason);
  Serial.print(F(" at "));
  Serial.println(location);

  // Visual + Audio
  setLED(false, true);
  triggerSiren(true);

  // LCD
  lcdShow("!! ALARM !!", reason);

  // GSM Alert
  char smsMsg[100];
  snprintf(smsMsg, sizeof(smsMsg),
    "SECURITY ALERT!\nReason: %s\nLocation: %s\nDevice: %s",
    reason, location, DEVICE_ID);
  gsmAlertAll(smsMsg);

  // AWS IoT
  mqttSendAlarm(reason, location);
}

void clearAlarm() {
  systemState = STATE_ARMED;
  triggerSiren(false);
  setLED(false, false);
  lockDoor();
  lcdShow("System ARMED", "All clear");
  Serial.println(F("[ALARM] Cleared"));
  mqttSendStatus();
}

// ─── RFID Processing ───────────────────────────────────────
String uidToString(byte uid[UID_SIZE]) {
  String s = "";
  for (int i = 0; i < UID_SIZE; i++) {
    if (uid[i] < 0x10) s += "0";
    s += String(uid[i], HEX);
    if (i < UID_SIZE - 1) s += ":";
  }
  s.toUpperCase();
  return s;
}

void processRFID() {
  if (!rfid.PICC_IsNewCardPresent()) return;
  if (!rfid.PICC_ReadCardSerial())   return;

  byte uid[UID_SIZE];
  for (int i = 0; i < UID_SIZE; i++) uid[i] = rfid.uid.uidByte[i];
  String uidStr = uidToString(uid);

  Serial.print(F("[RFID] Card detected: "));
  Serial.println(uidStr);

  lcdShowUID(uid);

  if (isAuthorizedCard(uid)) {
    // ── AUTHORIZED ──
    totalAccessCount++;
    Serial.println(F("[RFID] ACCESS GRANTED"));

    flashLED(true, 2);
    beep(2, 80, 60);
    lcdShow("ACCESS GRANTED", uidStr.c_str());

    // Disarm alarm if active
    if (systemState == STATE_ALARM) {
      clearAlarm();
    } else {
      // Toggle arm/disarm
      if (systemState == STATE_ARMED || systemState == STATE_DISARMED) {
        systemState = (systemState == STATE_ARMED) ? STATE_DISARMED : STATE_ARMED;
        if (systemState == STATE_DISARMED) {
          lcdShow("DISARMED", "Welcome!");
          unlockDoor();
          setLED(true, false);
        } else {
          lcdShow("ARMED", "Stay safe!");
          lockDoor();
          setLED(false, false);
        }
      }
    }

    mqttSendAccess(true, uidStr.c_str());

  } else {
    // ── UNAUTHORIZED ──
    Serial.println(F("[RFID] ACCESS DENIED"));
    flashLED(false, 3);
    beep(3, 200, 100);
    lcdShow("ACCESS DENIED", "Unauthorized!");

    // Trigger alarm if system is armed
    if (systemState == STATE_ARMED) {
      triggerAlarm("RFID_DENY", "MainDoor");
    }

    mqttSendAccess(false, uidStr.c_str());
  }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
  delay(LCD_MSG_MS);
}

// ─── PIR Motion Processing ─────────────────────────────────
void processPIR() {
  unsigned long now = millis();

  // Cooldown check
  if (now - lastPirTrigger < PIR_COOLDOWN_MS) {
    isrPirIndoor  = false;
    isrPirOutdoor = false;
    return;
  }

  bool triggered = false;
  const char* location = "";

  if (isrPirIndoor) {
    isrPirIndoor = false;
    Serial.println(F("[PIR] Indoor motion detected!"));
    triggered = true;
    location  = "Indoor";
  }

  if (isrPirOutdoor) {
    isrPirOutdoor = false;
    Serial.println(F("[PIR] Outdoor motion detected!"));
    triggered = true;
    location  = "Outdoor";
  }

  if (triggered && systemState == STATE_ARMED) {
    lastPirTrigger = now;
    triggerAlarm("PIR_MOTION", location);
  }
}

// ─── Door Sensor Processing ────────────────────────────────
void processDoorSensor() {
  if (!isrDoorSensor) return;
  isrDoorSensor = false;

  bool nowOpen = (digitalRead(DOOR_SENSOR) == LOW); // Reed switch: LOW = open
  if (nowOpen == doorOpen) return; // No change

  doorOpen = nowOpen;
  Serial.print(F("[DOOR] "));
  Serial.println(doorOpen ? F("OPENED") : F("CLOSED"));

  if (doorOpen && systemState == STATE_ARMED) {
    // Door opened without RFID auth = intrusion
    triggerAlarm("DOOR_FORCED", "MainDoor");
  }

  char payload[80];
  snprintf(payload, sizeof(payload),
    "{\"device\":\"%s\",\"door\":\"%s\"}",
    DEVICE_ID, doorOpen ? "OPEN" : "CLOSED");
  mqttPublish("security/door", payload);
}

// ─── Auto Door Lock ────────────────────────────────────────
void checkAutoLock() {
  if (doorUnlockTime > 0 &&
      millis() - doorUnlockTime > DOOR_UNLOCK_MS) {
    lockDoor();
    doorUnlockTime = 0;
    Serial.println(F("[LOCK] Auto-locked after timeout"));
    lcdShow("System ARMED", "Door locked");
  }
}

// ─── Alarm Auto-Clear ──────────────────────────────────────
void checkAlarmTimeout() {
  if (systemState == STATE_ALARM &&
      millis() - alarmStartTime > ALARM_DURATION_MS) {
    Serial.println(F("[ALARM] Timeout — auto clearing"));
    clearAlarm();
  }
}

// ─── Periodic Status ───────────────────────────────────────
void sendPeriodicStatus() {
  if (millis() - lastStatusSent > 60000) { // Every 60 seconds
    lastStatusSent = millis();
    mqttSendStatus();
    Serial.print(F("[STATUS] Armed="));
    Serial.print(systemState == STATE_ARMED ? "YES" : "NO");
    Serial.print(F(" | Cards="));
    Serial.print(authorizedCards);
    Serial.print(F(" | Alarms="));
    Serial.print(totalAlarmCount);
    Serial.print(F(" | Access="));
    Serial.println(totalAccessCount);
  }
}

// ─── Serial Command Handler (debug/config) ─────────────────
void handleSerialCommands() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();

  if (cmd == "arm") {
    systemState = STATE_ARMED;
    setLED(false, false);
    lcdShow("System ARMED", "");
    Serial.println(F("[CMD] Armed"));

  } else if (cmd == "disarm") {
    systemState = STATE_DISARMED;
    setLED(true, false);
    lcdShow("System DISARMED", "");
    if (systemState == STATE_ALARM) clearAlarm();
    Serial.println(F("[CMD] Disarmed"));

  } else if (cmd == "status") {
    Serial.print(F("State: "));
    Serial.println(systemState);
    Serial.print(F("Cards: "));  Serial.println(authorizedCards);
    Serial.print(F("Alarms: ")); Serial.println(totalAlarmCount);
    Serial.print(F("Access: ")); Serial.println(totalAccessCount);
    Serial.print(F("Door: "));   Serial.println(doorOpen ? "OPEN" : "CLOSED");

  } else if (cmd == "enroll") {
    Serial.println(F("Enroll mode: tap a card within 10 seconds..."));
    lcdShow("ENROLL MODE", "Tap card now...");
    unsigned long t = millis();
    while (millis() - t < 10000) {
      if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
        byte uid[UID_SIZE];
        for (int i = 0; i < UID_SIZE; i++) uid[i] = rfid.uid.uidByte[i];
        String uidStr = uidToString(uid);
        if (addCard(uid)) {
          Serial.print(F("Card enrolled: ")); Serial.println(uidStr);
          lcdShow("Card Enrolled!", uidStr.c_str());
          beep(3, 100);
        } else {
          Serial.println(F("Already enrolled or storage full!"));
          lcdShow("Already exists", "or FULL");
        }
        rfid.PICC_HaltA();
        rfid.PCD_StopCrypto1();
        delay(2000);
        break;
      }
      delay(100);
    }
    lcdShow("System ARMED", "Ready");

  } else if (cmd == "remove") {
    Serial.println(F("Remove mode: tap card to remove..."));
    lcdShow("REMOVE MODE", "Tap card now...");
    unsigned long t = millis();
    while (millis() - t < 10000) {
      if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
        byte uid[UID_SIZE];
        for (int i = 0; i < UID_SIZE; i++) uid[i] = rfid.uid.uidByte[i];
        String uidStr = uidToString(uid);
        if (removeCard(uid)) {
          Serial.print(F("Card removed: ")); Serial.println(uidStr);
          lcdShow("Card Removed!", uidStr.c_str());
          beep(2, 200);
        } else {
          Serial.println(F("Card not found!"));
          lcdShow("Not Found!", "");
        }
        rfid.PICC_HaltA();
        rfid.PCD_StopCrypto1();
        delay(2000);
        break;
      }
      delay(100);
    }
    lcdShow("System ARMED", "Ready");

  } else if (cmd == "listcards") {
    Serial.print(F("Authorized cards: "));
    Serial.println(authorizedCards);
    byte uid[UID_SIZE];
    for (int i = 0; i < authorizedCards; i++) {
      eepromLoadUID(i, uid);
      Serial.print(i + 1); Serial.print(F(". "));
      Serial.println(uidToString(uid));
    }

  } else if (cmd == "test_alarm") {
    Serial.println(F("Testing alarm..."));
    triggerAlarm("TEST", "Console");

  } else if (cmd == "test_sms") {
    Serial.println(F("Sending test SMS..."));
    gsmAlertAll("TEST: Security system active. Device: " DEVICE_ID);

  } else if (cmd == "clear") {
    clearAlarm();

  } else if (cmd == "help") {
    Serial.println(F("Commands: arm | disarm | status | enroll | remove | listcards | test_alarm | test_sms | clear | help"));
  }
}

// ─── SETUP ─────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println(F("=========================================="));
  Serial.println(F("  Arduino Smart Security System"));
  Serial.println(F("  DigitalMonk Case Study"));
  Serial.println(F("  RFID + PIR + GSM + AWS IoT"));
  Serial.println(F("=========================================="));

  // GPIO Setup
  pinMode(PIR_INDOOR,   INPUT);
  pinMode(PIR_OUTDOOR,  INPUT);
  pinMode(DOOR_SENSOR,  INPUT_PULLUP);
  pinMode(RELAY_LOCK,   OUTPUT);
  pinMode(RELAY_SIREN,  OUTPUT);
  pinMode(BUZZER_PIN,   OUTPUT);
  pinMode(LED_GREEN,    OUTPUT);
  pinMode(LED_RED,      OUTPUT);

  // Safe defaults
  digitalWrite(RELAY_LOCK,  HIGH); // Locked
  digitalWrite(RELAY_SIREN, HIGH); // Siren off
  digitalWrite(BUZZER_PIN,  LOW);
  setLED(false, false);

  // Interrupts
  attachInterrupt(digitalPinToInterrupt(PIR_INDOOR),  pirIndoorISR,  RISING);
  attachInterrupt(digitalPinToInterrupt(PIR_OUTDOOR), pirOutdoorISR, RISING);
  attachInterrupt(digitalPinToInterrupt(DOOR_SENSOR), doorSensorISR, CHANGE);

  // RFID
  SPI.begin();
  rfid.PCD_Init();
  rfid.PCD_SetAntennaGain(rfid.RxGain_max);
  Serial.println(F("[RFID] Initialized"));

  // LCD
  lcd.init();
  lcd.backlight();
  lcdShow("Smart Security", "Initializing...");

  // EEPROM — load stored card count
  authorizedCards = eepromLoadCardCount();
  Serial.print(F("[EEPROM] Loaded "));
  Serial.print(authorizedCards);
  Serial.println(F(" authorized cards"));

  // GSM
  gsmSerial.begin(9600);
  delay(2000);
  gsmInit();

  // ESP8266 bridge
  espSerial.begin(115200);
  delay(1000);
  espSerial.println(F("INIT:" DEVICE_ID));

  // Startup beep + LED sequence
  beep(3, 100, 60);
  setLED(true, false);
  delay(500);
  setLED(false, false);

  // Ready
  lcdShow("System ARMED", "Ready  [" DEVICE_ID "]");
  systemState = STATE_ARMED;
  lastStatusSent = millis();

  Serial.println(F("[BOOT] System ready. Type 'help' for commands."));
}

// ─── LOOP ──────────────────────────────────────────────────
void loop() {
  // Process ISR flags
  processPIR();
  processDoorSensor();

  // RFID scan
  processRFID();

  // Timers
  checkAutoLock();
  checkAlarmTimeout();

  // Periodic status publish
  sendPeriodicStatus();

  // Serial config commands
  handleSerialCommands();

  // Alarm beep (non-blocking tick)
  if (systemState == STATE_ALARM) {
    static unsigned long lastBeepTick = 0;
    if (millis() - lastBeepTick > 500) {
      beepAlarm();
      lastBeepTick = millis();
    }
  }

  delay(20);
}
