/*
 * ============================================================
 *   ESP8266 AWS IoT Bridge
 *   Arduino Smart Security System — DigitalMonk
 *
 *   This sketch runs on a SEPARATE ESP8266 module (e.g. NodeMCU)
 *   connected to Arduino via SoftwareSerial.
 *
 *   It acts as a co-processor:
 *   - Arduino sends "MQTT:topic:payload" strings via Serial
 *   - ESP8266 connects to WiFi + AWS IoT and publishes
 *   - ESP8266 also subscribes and forwards commands back to Arduino
 *
 *   AWS IoT Setup:
 *   1. Create a Thing in AWS IoT Core
 *   2. Download certificates (cert.pem, private.key, root-CA.pem)
 *   3. Paste certificate content into the defines below
 *   4. Update AWS_ENDPOINT with your endpoint URL
 *
 *   Wiring (ESP8266 NodeMCU):
 *   ESP8266 D7 (GPIO13) → Arduino Pin 12 (SoftSerial RX)
 *   ESP8266 D8 (GPIO15) → Arduino Pin 13 (SoftSerial TX)
 *   ESP8266 GND         → Arduino GND
 *   ESP8266 3.3V        → 3.3V supply (NOT Arduino 3.3V — use LDO)
 *
 *   Libraries needed:
 *   - ESP8266WiFi (built-in)
 *   - PubSubClient by Nick O'Leary
 *   - WiFiClientSecureBearSSL (built-in with ESP8266 core)
 * ============================================================
 */

#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <time.h>

// ─── WiFi ──────────────────────────────────────────────────
#define WIFI_SSID      "YOUR_WIFI_SSID"
#define WIFI_PASSWORD  "YOUR_WIFI_PASSWORD"

// ─── AWS IoT ───────────────────────────────────────────────
#define AWS_ENDPOINT   "YOUR_ID.iot.YOUR_REGION.amazonaws.com"
#define AWS_PORT       8883
#define THING_NAME     "SmartSecurityArduino"

// ─── Topics ────────────────────────────────────────────────
#define TOPIC_ALARM    "security/alarm"
#define TOPIC_ACCESS   "security/access"
#define TOPIC_STATUS   "security/status"
#define TOPIC_DOOR     "security/door"
#define TOPIC_CMD      "security/command"   // Subscribe — commands from cloud

// ─── AWS Certificates ──────────────────────────────────────
// Paste your AWS IoT certificate content below.
// Get from AWS Console → IoT Core → Things → Certificates

// Device Certificate (cert.pem)
static const char DEVICE_CERT[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
PASTE YOUR DEVICE CERTIFICATE HERE
-----END CERTIFICATE-----
)EOF";

// Device Private Key (private.key)
static const char PRIVATE_KEY[] PROGMEM = R"EOF(
-----BEGIN RSA PRIVATE KEY-----
PASTE YOUR PRIVATE KEY HERE
-----END RSA PRIVATE KEY-----
)EOF";

// AWS Root CA (AmazonRootCA1.pem)
static const char ROOT_CA[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
PASTE ROOT CA HERE
-----END CERTIFICATE-----
)EOF";

// ─── Objects ───────────────────────────────────────────────
BearSSL::WiFiClientSecure  wifiClient;
BearSSL::X509List          certList(ROOT_CA);
BearSSL::X509List          clientCert(DEVICE_CERT);
BearSSL::PrivateKey        privateKey(PRIVATE_KEY);
PubSubClient               mqttClient(wifiClient);

// ─── MQTT Callback (cloud → Arduino) ──────────────────────
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String msg = "";
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];

  Serial.print("CMD from cloud: ");
  Serial.println(msg);

  // Forward to Arduino via hardware serial
  Serial1.print("CMD:");
  Serial1.println(msg);
}

// ─── WiFi Connect ──────────────────────────────────────────
void connectWiFi() {
  Serial.print("Connecting to WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int retries = 0;
  while (WiFi.status() != WL_CONNECTED && retries < 30) {
    delay(500); Serial.print(".");
    retries++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected! IP: " + WiFi.localIP().toString());
  } else {
    Serial.println("\nWiFi FAILED");
  }
}

// ─── Sync Time (required for TLS cert validation) ─────────
void syncTime() {
  configTime(3 * 3600, 0, "pool.ntp.org", "time.nist.gov");
  Serial.print("Syncing time");
  while (time(nullptr) < 8 * 3600 * 2) { delay(500); Serial.print("."); }
  Serial.println(" OK");
}

// ─── AWS IoT Connect ───────────────────────────────────────
void connectAWS() {
  wifiClient.setTrustAnchors(&certList);
  wifiClient.setClientRSACert(&clientCert, &privateKey);

  mqttClient.setServer(AWS_ENDPOINT, AWS_PORT);
  mqttClient.setCallback(mqttCallback);
  mqttClient.setBufferSize(512);

  Serial.print("Connecting to AWS IoT...");
  while (!mqttClient.connected()) {
    if (mqttClient.connect(THING_NAME)) {
      Serial.println(" Connected!");
      mqttClient.subscribe(TOPIC_CMD);
      // Publish online status
      mqttClient.publish("security/status",
        "{\"device\":\"SmartSecurityArduino\",\"status\":\"online\"}");
    } else {
      Serial.print(" Failed rc=");
      Serial.println(mqttClient.state());
      delay(5000);
    }
  }
}

// ─── Parse and Publish Messages from Arduino ───────────────
void processArduinoMessage(String msg) {
  // Format: "MQTT:topic:payload"
  // or "INIT:device_id"

  if (msg.startsWith("INIT:")) {
    Serial.println("Arduino init: " + msg.substring(5));
    return;
  }

  if (!msg.startsWith("MQTT:")) return;

  int firstColon = msg.indexOf(':', 5);
  if (firstColon < 0) return;

  String topic   = msg.substring(5, firstColon);
  String payload = msg.substring(firstColon + 1);

  topic.trim();
  payload.trim();

  Serial.print("Publishing → ");
  Serial.print(topic);
  Serial.print(": ");
  Serial.println(payload);

  if (mqttClient.connected()) {
    mqttClient.publish(topic.c_str(), payload.c_str());
  } else {
    Serial.println("MQTT not connected — queuing...");
    connectAWS();
    mqttClient.publish(topic.c_str(), payload.c_str());
  }
}

// ─── SETUP ─────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);    // Debug output
  Serial1.begin(115200);   // Communication with Arduino (TX=GPIO2 on ESP8266)

  Serial.println("\n=== ESP8266 AWS IoT Bridge ===");
  Serial.println("Smart Security System — DigitalMonk");

  connectWiFi();
  syncTime();
  connectAWS();

  Serial.println("Bridge ready — listening for Arduino messages...");
  Serial1.println("BRIDGE:READY");
}

// ─── LOOP ──────────────────────────────────────────────────
void loop() {
  // Maintain MQTT connection
  if (!mqttClient.connected()) {
    Serial.println("MQTT disconnected — reconnecting...");
    connectAWS();
  }
  mqttClient.loop();

  // Read messages from Arduino
  static String inputBuffer = "";
  while (Serial1.available()) {
    char c = Serial1.read();
    if (c == '\n') {
      if (inputBuffer.length() > 0) {
        processArduinoMessage(inputBuffer);
        inputBuffer = "";
      }
    } else {
      inputBuffer += c;
    }
  }

  // Heartbeat every 30s
  static unsigned long lastHB = 0;
  if (millis() - lastHB > 30000) {
    lastHB = millis();
    if (mqttClient.connected()) {
      mqttClient.publish("security/heartbeat",
        "{\"device\":\"bridge\",\"rssi\":" + String(WiFi.RSSI()) + "}");
    }
  }
}
